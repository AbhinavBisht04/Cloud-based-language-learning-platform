---
sidebar_position: 5
---
# Learner Profile Ingestion Diagram

![Learner Profile Ingestione Diagram](./img/student_learning_profile/learner_profile_ingestion.png)