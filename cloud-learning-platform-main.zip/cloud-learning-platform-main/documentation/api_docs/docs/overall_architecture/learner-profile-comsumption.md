---
sidebar_position: 4
---
# Learner Profile Consumption Diagram

![Learner Profile Consumption Diagram](./img/student_learning_profile/learner_profile_consumption.png)