---
sidebar_position: 3
---
# Skill Aligment Architecture Diagram

![Skill Aligment Architecture Diagram](./img/skill_service/skill_alignment_architecture.png)