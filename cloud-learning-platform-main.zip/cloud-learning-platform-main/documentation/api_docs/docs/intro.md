---
sidebar_position: 1
slug: /
---
# Introduction

Cloud Learning Platform(CLP) is a Google Cloud solution designed for education aimed to radically transform and optimize the academic operations of universities and schools, providing a personalized learning experience 
at scale while enhancing the quality of education. AI Tutor and Competency Knowledge Tool can be considered as one of the first applications built on top of the Cloud Learning Platform APIs.


